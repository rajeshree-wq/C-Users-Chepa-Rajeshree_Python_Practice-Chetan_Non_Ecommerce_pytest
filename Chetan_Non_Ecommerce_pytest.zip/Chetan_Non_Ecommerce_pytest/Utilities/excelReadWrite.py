import openpyxl

# wb=openpyxl.Workbook()
# ws=wb.active
# c1=ws.cell(row=1,column=1)
# c1.value="Rajeshree"
# wb.save("C:\\Users\\Chepa\\Rajeshree_Python_Practice\\Chetan_Non_Ecommerce_pytest\\TestData\\my.xlsx")

# wb=openpyxl.load_workbook("C:\\Users\\Chepa\\Rajeshree_Python_Practice\\Chetan_Non_Ecommerce_pytest\\TestData\\my.xlsx")
# ws=wb.active
# rows=ws.max_row
# cols=ws.max_column
# print(rows,cols)
# for i in range(1,rows+1):
#     for j in range(1,cols+1):
#         print(ws.cell(i,j).value)








